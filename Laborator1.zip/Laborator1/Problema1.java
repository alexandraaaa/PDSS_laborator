abstract class Motor {
	private int putere;
	private float cupluMaxim;
	
	public Motor (int putere, float cupluMaxim) {
		this.putere = putere;
		this.cupluMaxim = cupluMaxim;
	}
	
	public String toString() {
		return "putere : " + putere + " cupluMaxim : " + cupluMaxim;
	}
}

class MotorDiesel extends Motor {
	public MotorDiesel(int putere, float cupluMaxim) {
		super(putere, cupluMaxim);
	}
	
	public String toString() {
		return " Motor Diesel : " + super.toString() + "\n";
	}
}

class MotorBenzina extends Motor {
	private boolean catalizator;
	
	public MotorBenzina(int putere, float cupluMaxim, boolean catalizator) {
		super(putere, cupluMaxim);
		this.catalizator = catalizator;
	}
	
	public String toString() {
		return " Motor Benzina : " + super.toString() + " catalizator : " + catalizator + "\n";
	}
}

abstract class Masina { 
	private String marca;
	private String tip;
	private int nrLocuri;
	private int nrUsi;
	private Motor motor;
	private float viteza;
	private String culoare;
	
	public Masina(String marca, String tip, int nrLocuri, int nrUsi, Motor motor, float viteza, String culoare) {
		this.marca = marca;
		this.tip = tip;
		this.nrLocuri = nrLocuri;
		this.nrUsi = nrUsi;
		this.motor = motor;
		this.viteza = viteza;
		this.culoare = culoare;
	}
	
	public String toString() {
		return "marca : " + marca + " tip : " + tip + " nrLocuri : " + nrLocuri + " nrUsi : " + nrUsi + motor + " viteza : " + viteza + " culoare : " + culoare;
	}
}

class MasinaSUV extends Masina {
	private String gardaSol;
	private boolean tip4x4;
	
	public MasinaSUV(String marca, String tip, int nrLocuri, int nrUsi, Motor motor, float viteza, String culoare, String gardaSol, boolean tip4x4) {
		super(marca, tip, nrLocuri, nrUsi, motor, viteza, culoare);
		this.gardaSol = gardaSol;
		this.tip4x4 = tip4x4;
	}
	
	public String toString() {
		return "\t\tMasina SUV\n" + super.toString() + " gardaSol : " + gardaSol + " tip4x4 : " + tip4x4 + "\n";
	}
}

class MasinaTurism extends Masina {
	public MasinaTurism(String marca, String tip, int nrLocuri, int nrUsi, Motor motor, float viteza, String culoare) {
		super(marca, tip, nrLocuri, nrUsi, motor, viteza, culoare);
	}
	
	public String toString() {
		return "\t\tMasina Turism\n" + super.toString() + "\n";
	}
}

class Main {
	public static void main(String[] args) {
		Motor motor1 = new MotorBenzina(5, 5, true);
		Masina masina1 = new MasinaSUV("SUV", "SUV", 5, 4, motor1, 200, "negru", "gardaSol", true);
		System.out.println(masina1);
		
		Motor motor2 =  new MotorDiesel(6,6);
		Masina masina2 = new MasinaTurism("Tursim", "Turism", 5, 5, motor2, 150, "gri");
		System.out.println(masina2);
	}
}
