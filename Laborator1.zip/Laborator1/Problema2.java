abstract class Accesorii {
	private float pret;
	
	public Accesorii(float pret) {
		this.pret = pret;
	}
	
	public String toString() {
		return " pret : " + pret;
	}
}

abstract class Bijuterii extends Accesorii {
	private String culoare;
	private boolean pietre;
	
	public Bijuterii(float pret, String culoare, boolean pietre) {
		super(pret);
		this.culoare = culoare;
		this.pietre = pietre;
	}
	
	public String toString() {
		return super.toString() + " culoare : " + culoare + " pietre : " + pietre;
	}
}

class Ceas extends Bijuterii {
	private float timpBaterie;
	
	public Ceas(float pret, String culoare, boolean pietre, float timpBaterie) {
		super(pret, culoare, pietre);
		this.timpBaterie = timpBaterie;
	}
	
	public String toString() {
		return "\t\tCeas\n" + super.toString() + " timpBaterie : " + timpBaterie + "\n";
	}
}

class AlteBijuterii extends Bijuterii {
	public AlteBijuterii(float pret, String culoare, boolean pietre) {
		super(pret, culoare, pietre);
	}
	
	public String toString() {
		return "\t\tAlte Bijuterii\n" + super.toString() + "\n";
	}
}

class Palarie extends Accesorii {
	private String anotimp;
	
	public Palarie(float pret, String anotimp) {
		super(pret);
		this.anotimp = anotimp;
	}
	
	public String toString() {
		return super.toString() + " anotimp : " + anotimp + "\n";
	}
}

abstract class Genti extends Accesorii {
	private boolean pieleNaturala;
	
	public Genti(float pret, boolean pieleNaturala) {
		super(pret);
		this.pieleNaturala = pieleNaturala;
	}
	
	public String toString() {
		return super.toString() + " pieleNaturala : " + pieleNaturala + "\n";
	}
}

class GeantaMica extends Genti {
	public GeantaMica(float pret, boolean pieleNaturala) {
		super(pret, pieleNaturala);
	}
	
	public String toString() {
		return "\t\tGeanta Mica\n" + super.toString();
	}
}

class GeantaMedie extends Genti {
	public GeantaMedie(float pret, boolean pieleNaturala) {
		super(pret, pieleNaturala);
	}
	
	public String toString() {
		return "\t\tGeanta Medie\n" + super.toString();
	}
}

class GeantaMare extends Genti {
	public GeantaMare(float pret, boolean pieleNaturala) {
		super(pret, pieleNaturala);
	}
	
	public String toString() {
		return "\t\tGeanta Mare\n" + super.toString();
	}
}

class Main {
	public static void main(String[] args) {
		Accesorii a1 = new Ceas(20, "negru", true, 24);
		System.out.println(a1);
		
		Accesorii a2 = new AlteBijuterii(100, "auriu", true);
		System.out.println(a2);
		
		Accesorii a3 = new Palarie(100, "iarna");
		System.out.println(a3);
		
		Accesorii a4 = new GeantaMedie(150, true);
		System.out.println(a4);
	}
}